package com.cts.policyManagmentSystem.dao;

import java.util.List;

import com.cts.policyManagmentSystem.bean.Policy;

public interface PolicyDAO {
	
	public String addPolicy(Policy policy);
	public List<Policy> getAllPolicy();
	public String updatePolicy(Policy policy);
	public Policy getPolicyById(String policyId);
    public List<Policy> searchPolicyByValues(String search_by,String search_value);
	
}
